import time
import requests
from bs4 import BeautifulSoup

def main():
    url = "http://68k.news"
    response = requests.get(url)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    links = soup.find_all("a")

    content = [a.get_text(strip=True) for a in links if a.get_text(strip=True)]
    final = []
    i = 13
    for i in range(13, len(content), 6):
        final.append(content[i])
    with open("index.html", "w") as f:
        f.write('''<!DOCTYPE html>
<html lang="en">
<head>
    <title>Headlines.net: Your one stop for the latest news</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="favicon.png">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>

<body>
    <center>
        <div class="bg" id="bg">
        </div>

        <div class="content">
            <div class="main">''')
        i = 0
        for i in range(len(final)):
            f.write('<h2 id="headlinetext">' + final[i] + "</h2> \n")
        f.write("""
            </div>
        </div>
    </center>
</body>
</html>""")
print("Headline Grabber")
print("Version 1.1")
print("2026-07-18")
try:
    while True:
        print("Downloading news")
        print("Compiling webpage")
        main()
        print("Finished")
        print("Waiting")
        time.sleep(1800)  
except:
    print("Error has occured")
